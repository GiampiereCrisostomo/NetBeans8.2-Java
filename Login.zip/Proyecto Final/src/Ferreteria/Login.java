
package Ferreteria;

import java.awt.Color;
import javax.swing.*;

/**
 *
 * @author Giampiere Crisóstomo
 */
public class Login extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public Login() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupousuario = new javax.swing.ButtonGroup();
        Fondo = new javax.swing.JPanel();
        PanelLogin = new javax.swing.JPanel();
        jRusuario = new javax.swing.JRadioButton();
        jRadministrador = new javax.swing.JRadioButton();
        Cerrar = new javax.swing.JLabel();
        txtusuario = new javax.swing.JTextField();
        jPContraseña = new javax.swing.JPasswordField();
        Login = new javax.swing.JLabel();
        txtIngresar = new javax.swing.JLabel();
        Avatar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(400, 500));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setPreferredSize(new java.awt.Dimension(400, 500));
        Fondo.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                FondoMouseDragged(evt);
            }
        });
        Fondo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                FondoMousePressed(evt);
            }
        });
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelLogin.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PanelLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        grupousuario.add(jRusuario);
        jRusuario.setText("Cajero");
        PanelLogin.add(jRusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, -1, -1));

        grupousuario.add(jRadministrador);
        jRadministrador.setText("Administrador");
        PanelLogin.add(jRadministrador, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, -1, -1));

        Cerrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/icons8-cerrar-ventana-32.png"))); // NOI18N
        Cerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CerrarMouseClicked(evt);
            }
        });
        PanelLogin.add(Cerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, -1, -1));

        txtusuario.setFont(new java.awt.Font("Roboto", 0, 11)); // NOI18N
        txtusuario.setForeground(new java.awt.Color(204, 204, 204));
        txtusuario.setText("Ingrese su nombre de usuario");
        txtusuario.setBorder(null);
        txtusuario.setCaretColor(new java.awt.Color(204, 204, 204));
        txtusuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtusuarioMousePressed(evt);
            }
        });
        PanelLogin.add(txtusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 200, 30));

        jPContraseña.setForeground(new java.awt.Color(204, 204, 204));
        jPContraseña.setBorder(null);
        jPContraseña.setCaretColor(new java.awt.Color(204, 204, 204));
        jPContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPContraseñaMousePressed(evt);
            }
        });
        PanelLogin.add(jPContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 350, 200, 20));

        Login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Avatar_Container.png"))); // NOI18N
        PanelLogin.add(Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 400, 80));

        txtIngresar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        txtIngresar.setForeground(new java.awt.Color(255, 255, 255));
        txtIngresar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtIngresar.setText("Sign In");
        txtIngresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txtIngresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtIngresarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtIngresarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtIngresarMouseExited(evt);
            }
        });
        PanelLogin.add(txtIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 410, 116, 40));

        Avatar.setBackground(new java.awt.Color(102, 102, 255));
        Avatar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Loginv1 (3).png"))); // NOI18N
        PanelLogin.add(Avatar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        Fondo.add(PanelLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtusuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtusuarioMousePressed
        // Ingresar Usuario: y Vaciar Campo
        if (txtusuario.getText().equals("Ingrese su nombre de usuario")) {
            txtusuario.setText("");
            txtusuario.setForeground(Color.black);
        }
        if (String.valueOf(jPContraseña.getPassword()).isEmpty()) {
            jPContraseña.setText("********");
            jPContraseña.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtusuarioMousePressed

    private void jPContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPContraseñaMousePressed
        // Ingresar Contraseña: y Vaciar Campos
        if (String.valueOf(jPContraseña.getPassword()).equals("********")) {
            jPContraseña.setText("");
            jPContraseña.setForeground(Color.black);
        }
        if (txtusuario.getText().isEmpty()) {
            txtusuario.setText("Ingrese su nombre de usuario");
            txtusuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_jPContraseñaMousePressed

    private void FondoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FondoMousePressed
        // Mover la pantalla
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_FondoMousePressed

    private void FondoMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FondoMouseDragged
        //Mover la Ventana
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_FondoMouseDragged

    private void txtIngresarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtIngresarMouseExited
        //Color de Boton
        txtIngresar.setBackground(new Color(0,134,190));
    }//GEN-LAST:event_txtIngresarMouseExited

    private void txtIngresarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtIngresarMouseEntered
        // Color de Boton
        txtIngresar.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_txtIngresarMouseEntered

    private void txtIngresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtIngresarMouseClicked
        //Ingresar al Sistema Cajero & Administrador  
        // Sección 1: Captura lo que se ha digitado en el JPasswordField
        char clave[]=jPContraseña.getPassword();
        //Sección 2: Definimos Usuario y Contraseña     
        String clavedef=new String(clave);
        if (txtusuario.getText().equals("Alex") && clavedef.equals("12345")){
             
            if(jRusuario.isSelected()){ 
                
                 this.dispose(); 
                 JOptionPane.showMessageDialog(null, "Bienvenido: "+"\n Has ingresado "
                 + "satisfactoriamente al sistema", "Mensaje de bienvenida",
                 JOptionPane.INFORMATION_MESSAGE);
                
                 // Mostramos la Ventana Caja
                 Caja formformulario1 = new Caja();
                 formformulario1.setVisible(true);
                 
                 

            } else if(jRadministrador.isSelected()){
                
                 this.dispose(); 
                 JOptionPane.showMessageDialog(null, "Bienvenido: "+"\n Has ingresado "
                 + "satisfactoriamente al sistema", "Mensaje de bienvenida",
                 JOptionPane.INFORMATION_MESSAGE);
            
                 /*this.dispose(); 
                 JOptionPane.showMessageDialog(null, "Bienvenido: "+"\n Has ingresado "
                 + "satisfactoriamente al sistema", "Mensaje de bienvenida",
                 JOptionPane.INFORMATION_MESSAGE);
                 */
                 // Mostramos la Ventana Caja
                 Administrador formformulario1 = new Administrador ();
                 formformulario1.setVisible(true);
                
                }
             }  else {
                 
            JOptionPane.showMessageDialog(null, "Acceso denegado:\n"
            + "Seleccione un Usuario Revise su usuario y/o contraseña si son correctos",  
            "Acceso denegado", JOptionPane.ERROR_MESSAGE);
            
                        
        
       }             
       
    }//GEN-LAST:event_txtIngresarMouseClicked

    private void CerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarMouseClicked
        // Cerrar Ventana de Login
        System.exit(0);
    }//GEN-LAST:event_CerrarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Avatar;
    private javax.swing.JLabel Cerrar;
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Login;
    private javax.swing.JPanel PanelLogin;
    private javax.swing.ButtonGroup grupousuario;
    private javax.swing.JPasswordField jPContraseña;
    private javax.swing.JRadioButton jRadministrador;
    private javax.swing.JRadioButton jRusuario;
    private javax.swing.JLabel txtIngresar;
    private javax.swing.JTextField txtusuario;
    // End of variables declaration//GEN-END:variables
}
